// Freezes all intrinsics
// eslint-disable-next-line no-undef,import/unambiguous
lockdown({
  consoleTaming: 'unsafe',
  errorTaming: 'unsafe',
  mathTaming: 'unsafe',
  dateTaming: 'unsafe',
})
